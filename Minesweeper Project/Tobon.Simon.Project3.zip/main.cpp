#include "game.h"
#include <cstdio>
int main() {
	
	Game game;
	game.runGame();

}